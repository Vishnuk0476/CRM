ALTER TABLE `crm_orders` ADD COLUMN `case_id` int(11) DEFAULT NULL AFTER `id`;
