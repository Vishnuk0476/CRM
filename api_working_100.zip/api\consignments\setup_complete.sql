-- ============================================================
-- Panya Global — COMPLETE SETUP SQL
-- MySQL 5.7+ compatible
-- Just run this ONCE in phpMyAdmin and you're done!
-- ============================================================

-- ─── Consignments Table ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS consignments (
    id                  CHAR(36) NOT NULL,
    consignment_number  VARCHAR(30) NOT NULL DEFAULT '',
    lr_number           VARCHAR(100) DEFAULT NULL,
    awb_number          VARCHAR(100) DEFAULT NULL,
    customer_name       VARCHAR(255) NOT NULL,
    customer_email      VARCHAR(255) NOT NULL,
    customer_phone      VARCHAR(30) NOT NULL,
    origin              VARCHAR(255) NOT NULL,
    destination         VARCHAR(255) NOT NULL,
    service_type        VARCHAR(100) NOT NULL DEFAULT 'Household Moving',
    description         TEXT,
    estimated_delivery  DATE DEFAULT NULL,
    status              ENUM('booked','picked_up','in_transit','out_for_delivery','delivered','cancelled') NOT NULL DEFAULT 'booked',
    tracking_steps      LONGTEXT DEFAULT NULL,
    notes               TEXT DEFAULT NULL,
    last_email_status   VARCHAR(50) DEFAULT NULL,
    last_email_error    TEXT DEFAULT NULL,
    last_email_sent_at  DATETIME DEFAULT NULL,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uniq_consignment_number (consignment_number),
    INDEX idx_status    (status),
    INDEX idx_email     (customer_email),
    INDEX idx_phone     (customer_phone),
    INDEX idx_lr        (lr_number),
    INDEX idx_awb       (awb_number),
    INDEX idx_created   (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─── Rate Limit Log Table ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS rate_limit_log (
    id           INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    rate_key     VARCHAR(255) NOT NULL,
    attempts     INT UNSIGNED NOT NULL DEFAULT 1,
    window_start INT UNSIGNED NOT NULL,
    UNIQUE KEY uk_rate_key (rate_key),
    INDEX idx_window (window_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─── Done ─────────────────────────────────────────────────────
SELECT 'ALL TABLES CREATED SUCCESSFULLY!' AS result;
