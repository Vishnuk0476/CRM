-- ============================================================
-- Panya Global — FINAL PRODUCTION UPGRADE (v5)
-- This script ensures your live database matches the new LR system.
-- Run this in phpMyAdmin on your LIVE server.
-- ============================================================

-- 1. Create LR Sequence Table (if not exists)
CREATE TABLE IF NOT EXISTS lr_sequence (
    id       TINYINT UNSIGNED NOT NULL DEFAULT 1,
    last_seq INT UNSIGNED     NOT NULL DEFAULT 16000,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed starting value (only if empty)
INSERT IGNORE INTO lr_sequence (id, last_seq) VALUES (1, 16000);

-- 2. Add Missing Columns to Consignments
-- (Using a procedure to avoid "Duplicate Column" errors)
DELIMITER //
CREATE PROCEDURE AddConsignmentColumns()
BEGIN
    -- Add consignor_name
    IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_name = 'consignments' AND column_name = 'consignor_name') THEN
        ALTER TABLE consignments ADD COLUMN consignor_name VARCHAR(255) DEFAULT NULL AFTER awb_number;
    END IF;

    -- Add consignor_address
    IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_name = 'consignments' AND column_name = 'consignor_address') THEN
        ALTER TABLE consignments ADD COLUMN consignor_address TEXT DEFAULT NULL AFTER consignor_name;
    END IF;

    -- Add packages_count
    IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_name = 'consignments' AND column_name = 'packages_count') THEN
        ALTER TABLE consignments ADD COLUMN packages_count INT UNSIGNED DEFAULT NULL AFTER consignor_address;
    END IF;

    -- Add lr_pdf_path
    IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_name = 'consignments' AND column_name = 'lr_pdf_path') THEN
        ALTER TABLE consignments ADD COLUMN lr_pdf_path VARCHAR(512) DEFAULT NULL AFTER packages_count;
    END IF;

    -- Add loaded_from_city
    IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_name = 'consignments' AND column_name = 'loaded_from_city') THEN
        ALTER TABLE consignments ADD COLUMN loaded_from_city VARCHAR(255) DEFAULT NULL AFTER lr_pdf_path;
    END IF;

    -- Add out_for_delivery_city
    IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_name = 'consignments' AND column_name = 'out_for_delivery_city') THEN
        ALTER TABLE consignments ADD COLUMN out_for_delivery_city VARCHAR(255) DEFAULT NULL AFTER loaded_from_city;
    END IF;

    -- Add consignee_address
    IF NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_name = 'consignments' AND column_name = 'consignee_address') THEN
        ALTER TABLE consignments ADD COLUMN consignee_address TEXT DEFAULT NULL AFTER destination;
    END IF;
END //
DELIMITER ;

CALL AddConsignmentColumns();
DROP PROCEDURE AddConsignmentColumns;

-- 3. Update existing records (Optional: If any records have NULL lr_number, you can auto-fill them)
-- UPDATE consignments SET lr_number = consignment_number WHERE lr_number IS NULL;

SELECT 'PRODUCTION UPGRADE V5 APPLIED SUCCESSFULLY!' AS result;
