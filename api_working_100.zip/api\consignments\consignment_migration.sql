-- ============================================================
-- Panya Global — Consignments Table Migration
-- Run this in PHPMyAdmin on the panyaglobal_db database
-- ============================================================

USE panyaglobal_db;

CREATE TABLE IF NOT EXISTS consignments (
    id                  CHAR(36) NOT NULL PRIMARY KEY,
    consignment_number  VARCHAR(30) NOT NULL UNIQUE,
    customer_name       VARCHAR(255) NOT NULL,
    customer_email      VARCHAR(255) NOT NULL,
    customer_phone      VARCHAR(30) NOT NULL,
    origin              VARCHAR(255) NOT NULL,
    destination         VARCHAR(255) NOT NULL,
    service_type        VARCHAR(100) NOT NULL DEFAULT 'Household Moving',
    description         TEXT,
    estimated_delivery  DATE,
    status              ENUM('booked','picked_up','in_transit','out_for_delivery','delivered','cancelled') NOT NULL DEFAULT 'booked',
    tracking_steps      JSON,
    notes               TEXT,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_consignment_number (consignment_number),
    INDEX idx_status (status),
    INDEX idx_email (customer_email),
    INDEX idx_created (created_at)
);

DELIMITER $$
DROP TRIGGER IF EXISTS before_insert_consignments$$
CREATE TRIGGER before_insert_consignments
BEFORE INSERT ON consignments
FOR EACH ROW
BEGIN
    IF NEW.id = '' OR NEW.id IS NULL THEN
        SET NEW.id = UUID();
    END IF;
    SET NEW.consignment_number = CONCAT('PGC', DATE_FORMAT(NOW(), '%Y%m%d'), '-', UPPER(SUBSTRING(NEW.id, 1, 8)));
END$$
DELIMITER ;
