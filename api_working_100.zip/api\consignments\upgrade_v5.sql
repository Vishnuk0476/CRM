-- ============================================================
-- Panya Global — Schema Upgrade v5
-- Adds consignee_address column for LR receipt
-- Run once in phpMyAdmin on panyaglobal_db (local + live)
-- ============================================================

USE panyaglobal_db;

-- Add consignee address column (safe to re-run with IF NOT EXISTS check)
ALTER TABLE consignments
    ADD COLUMN consignee_address TEXT DEFAULT NULL AFTER destination;

SELECT 'upgrade_v5 applied: consignee_address column added to consignments.' AS result;
