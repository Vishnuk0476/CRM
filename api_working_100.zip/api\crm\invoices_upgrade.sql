ALTER TABLE `crm_invoices`
ADD COLUMN `taxable_amount` decimal(10,2) DEFAULT '0.00' AFTER `discount_amount`,
ADD COLUMN `cgst_amount` decimal(10,2) DEFAULT '0.00' AFTER `taxable_amount`,
ADD COLUMN `sgst_amount` decimal(10,2) DEFAULT '0.00' AFTER `cgst_amount`,
ADD COLUMN `igst_amount` decimal(10,2) DEFAULT '0.00' AFTER `sgst_amount`;
