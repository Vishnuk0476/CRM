-- ============================================================
-- Panya Global — Schema Upgrade v4
-- LR sequence counter (starts at 16000, first LR = 16001)
-- Run once in phpMyAdmin on panyaglobal_db (local + live)
-- ============================================================

USE panyaglobal_db;

-- Global LR counter table (single row)
CREATE TABLE IF NOT EXISTS lr_sequence (
    id       TINYINT UNSIGNED NOT NULL DEFAULT 1,
    last_seq INT UNSIGNED     NOT NULL DEFAULT 16000,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed starting value (16000 so next generated LR = 16001)
INSERT IGNORE INTO lr_sequence (id, last_seq) VALUES (1, 16000);

-- Add consignor columns to consignments (safe to re-run)
ALTER TABLE consignments
    ADD COLUMN consignor_name         VARCHAR(255) DEFAULT NULL AFTER awb_number,
    ADD COLUMN consignor_address      TEXT         DEFAULT NULL AFTER consignor_name,
    ADD COLUMN packages_count         INT UNSIGNED DEFAULT NULL AFTER consignor_address,
    ADD COLUMN lr_pdf_path            VARCHAR(512) DEFAULT NULL AFTER packages_count,
    ADD COLUMN loaded_from_city       VARCHAR(255) DEFAULT NULL AFTER lr_pdf_path,
    ADD COLUMN out_for_delivery_city  VARCHAR(255) DEFAULT NULL AFTER loaded_from_city;

SELECT 'upgrade_v4 applied: lr_sequence starts at 16000 (first LR = 16001), consignor + lr_pdf_path columns added.' AS result;
