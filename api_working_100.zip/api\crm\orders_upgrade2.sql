ALTER TABLE `crm_orders` DROP FOREIGN KEY `fk_order_lead`;
ALTER TABLE `crm_orders` MODIFY `lead_id` INT DEFAULT NULL;
